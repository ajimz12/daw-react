function App() {
  return <h1 className="text-7xl text-amber-900">Examen DWEC 2025</h1>;
}

export default App;
